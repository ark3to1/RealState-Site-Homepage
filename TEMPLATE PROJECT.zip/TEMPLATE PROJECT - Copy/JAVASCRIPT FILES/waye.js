$(document).ready(function () {
    
    $(document).on('click', '.slider-dot', function () {

        let self = $(this);

        if (self.hasClass('d1')) { 
            $('.slider').css({
                "background-image": "url('../IMAGES/background image.jpg')",
                "background-size": "100% 100%",
                "background-repeat": "no-repeat",
                "transition": "0.4s"
            });
            
            $('.d1').css({
                "background-color": "white"
            });
            
            $('.d2').css({
                "background-color": "rgb(229, 204, 18)"
            });
            
            $('.d3').css({
                "background-color": "rgb(229, 204, 18)"
            });
        }

        if (self.hasClass('d2')) {
            $('.slider').css({
                "background-image": "url('../IMAGES/background image 1.jpg')",
                "background-size": "100% 100%",
                "background-repeat": "no-repeat",
                "transition": "0.4s"
            });

            $('.d1').css({
                "background-color": "rgb(229, 204, 18)"
            });
            
            $('.d2').css({
                "background-color": "white"
            });
            
            $('.d3').css({
                "background-color": "rgb(229, 204, 18)"
            });
        }

        if (self.hasClass('d3')) {
            $('.slider').css({
                "background-image": "url('../IMAGES/background image 2.jpg')",
                "background-size": "100% 100%",
                "background-repeat": "no-repeat",
                "transition": "0.4s"
            });

            $('.d1').css({
                "background-color": "rgb(229, 204, 18)"
            });
            
            $('.d2').css({
                "background-color": "rgb(229, 204, 18)"
            });
            
            $('.d3').css({
                "background-color": "white"
            });
        }

    });

    $(document).on('click', '.right-icon', function () {

        if( screen.width <= 800 ) {
            $( '.main-menu' ).toggle(500);
        }
    });

});
